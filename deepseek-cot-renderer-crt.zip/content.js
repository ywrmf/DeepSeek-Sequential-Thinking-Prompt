// DeepSeek COT Renderer - Retro Futurism Edition
(function () {
  'use strict';

  // ==================== 配置 ====================
  const CONFIG = {
    TEXT: {
      THINKING: '>_ THINKING',
      PROCESSING: 'PROCESSING...',
      COMPLETED: '>_ COMPLETE',
      TIME_UNIT: 's',
      INJECT_BTN: 'INJECT',
      INJECT_SUCCESS: 'DONE',
      INJECT_ERROR: 'ERROR',
      INJECT_LOADING: 'LOAD'
    },
    ICONS: {
      TOGGLE: '▶',
      INJECT: '►',
      SUCCESS: '✓',
      ERROR: '✗',
      LOADING: '◈'
    },
    SELECTORS: {
      CODE_BLOCK: '.md-code-block',
      LANGUAGE_LABEL: '.d813de27',
      PRE: 'pre',
      MESSAGE_CONTAINER: '.ds-markdown',
      INPUT_CONTAINER: '.ec4f5d61'
    },
    INPUT_SELECTORS: [
      '#chat-input',
      'textarea[placeholder]',
      'textarea',
      '.chat-input',
      '.input-area textarea',
      '[contenteditable="true"]',
      '.ql-editor',
      'div[role="textbox"]',
      '[data-placeholder]'
    ],
    CHECK_INTERVAL: 500
  };

  const cotRegistry = new WeakMap();
  let promptContent = '';
  let promptBtnInjected = false;
  let promptLoaded = false;
  let crtFilterInjected = false;

  // ==================== 调试日志 ====================
  function log(...args) {
    console.log('[COT Renderer]', ...args);
  }

  function warn(...args) {
    console.warn('[COT Renderer]', ...args);
  }

  function error(...args) {
    console.error('[COT Renderer]', ...args);
  }

  // ==================== 注入CRT滤镜 ====================
  function injectCRTFilter() {
    if (crtFilterInjected) return;
    
    const crtOverlay = document.createElement('div');
    crtOverlay.className = 'crt-overlay';
    crtOverlay.setAttribute('aria-hidden', 'true');
    document.body.appendChild(crtOverlay);
    
    crtFilterInjected = true;
    log('CRT filter injected');
  }

  // ==================== 隐藏原始按钮 ====================
  function hideOriginalButtons() {
    const toggleButtons = document.querySelectorAll('.ds-toggle-button');
    toggleButtons.forEach(btn => {
      const textSpan = btn.querySelector('._6dbc175, [class*="6dbc175"]');
      if (textSpan) {
        const text = textSpan.textContent.trim();
        if (text === '深度思考' || text === '联网搜索') {
          btn.style.display = 'none';
        }
      }
    });
  }

  // ==================== 加载 prompt.txt ====================
  async function loadPrompt() {
    if (promptLoaded && promptContent) {
      return true;
    }

    try {
      const url = chrome.runtime.getURL('prompt.txt');
      log('Loading prompt from:', url);
      
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      promptContent = await response.text();
      promptContent = promptContent.trim();
      
      if (promptContent) {
        promptLoaded = true;
        log('Prompt loaded successfully, length:', promptContent.length);
        return true;
      } else {
        warn('Prompt file is empty');
        return false;
      }
    } catch (err) {
      error('Error loading prompt:', err);
      return false;
    }
  }

  // ==================== COT 渲染器类 ====================
  class COTRenderer {
    constructor(codeBlock) {
      this.codeBlock = codeBlock;
      this.container = null;
      this.startTime = Date.now();
      this.isCompleted = false;
      this.lastContent = '';
      this.isExpanded = false;
      
      this.render();
    }

    render() {
      this.codeBlock.setAttribute('data-cot-processed', 'true');
      this.codeBlock.style.display = 'none';

      this.container = document.createElement('div');
      this.container.className = 'cot-container';

      this.header = document.createElement('div');
      this.header.className = 'cot-header';
      this.header.innerHTML = this.buildThinkingHeader();
      
      this.divider = document.createElement('div');
      this.divider.className = 'cot-divider';
      
      this.contentWrapper = document.createElement('div');
      this.contentWrapper.className = 'cot-content';
      
      this.contentText = document.createElement('div');
      this.contentText.className = 'cot-content-text';
      
      this.cursor = document.createElement('span');
      this.cursor.className = 'terminal-cursor';
      
      this.contentWrapper.appendChild(this.contentText);
      this.contentWrapper.appendChild(this.cursor);
      
      this.container.appendChild(this.header);
      this.container.appendChild(this.divider);
      this.container.appendChild(this.contentWrapper);

      this.codeBlock.parentNode.insertBefore(this.container, this.codeBlock);
      this.header.addEventListener('click', () => this.toggle());
      this.updateContent();
    }

    buildThinkingHeader() {
      return `
        <div class="cot-header-left">
          <span class="cot-prompt">>_</span>
          <span class="cot-title thinking">THINKING</span>
        </div>
        <div class="cot-header-right">
          <div class="cot-scanline-box">
            <div class="cot-scanlines"></div>
          </div>
          <span class="cot-processing">PROCESSING...</span>
        </div>
      `;
    }

    buildCompletedHeader(duration) {
      const timeDisplay = duration === "0.0" ? '' : 
        `<span class="cot-time">[${duration}${CONFIG.TEXT.TIME_UNIT}]</span>`;
      
      return `
        <div class="cot-header-left">
          <span class="cot-prompt">>_</span>
          <span class="cot-title completed">COMPLETE</span>
          ${timeDisplay}
        </div>
        <div class="cot-header-right">
          <div class="cot-status-indicator"></div>
        </div>
      `;
    }

    toggle() {
      this.isExpanded = !this.isExpanded;
      this.container.classList.toggle('expanded', this.isExpanded);
    }

    updateContent() {
      const pre = this.codeBlock.querySelector(CONFIG.SELECTORS.PRE);
      if (pre) {
        const newContent = pre.textContent || '';
        if (newContent !== this.lastContent) {
          this.contentText.innerHTML = this.parseMarkdown(newContent);
          this.lastContent = newContent;
          
          if (this.isExpanded) {
            this.contentWrapper.scrollTop = this.contentWrapper.scrollHeight;
          }
        }
      }
    }

    parseMarkdown(text) {
      let html = text;

      html = html.replace(/`([^`]+)`/g, '<code class="cot-inline-code">$1</code>');

      html = html.replace(/```(\w+)?\n?([\s\S]*?)```/g, (match, lang, code) => {
        return `<pre class="cot-code-block"><code>${code}</code></pre>`;
      });

      html = html.replace(/\*\*([^*\n]+)\*\*/g, '<strong class="cot-bold">$1</strong>');
      html = html.replace(/__([^_\n]+)__/g, '<strong class="cot-bold">$1</strong>');

      html = html.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
      html = html.replace(/(?<!_)_([^_\n]+)_(?!_)/g, '<em>$1</em>');

      html = html.replace(/~~([^~\n]+)~~/g, '<del class="cot-strikethrough">$1</del>');

      html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="cot-link" target="_blank">$1</a>');

      html = html.replace(/^### (.*$)/gim, '<h3 class="cot-h3">/// $1</h3>');
      html = html.replace(/^## (.*$)/gim, '<h2 class="cot-h2">// $1</h2>');
      html = html.replace(/^# (.*$)/gim, '<h1 class="cot-h1">/ $1</h1>');

      html = html.replace(/\n/g, '<br>');

      return html;
    }

    complete() {
      if (this.isCompleted) return;

      this.isCompleted = true;
      this.container.classList.add('completed');
      const duration = ((Date.now() - this.startTime) / 1000).toFixed(1);
      this.header.innerHTML = this.buildCompletedHeader(duration);
      this.updateContent();
      
      this.cursor.style.display = 'none';
    }
  }

  // ==================== 查找输入框 ====================
  function findInputElement() {
    for (const selector of CONFIG.INPUT_SELECTORS) {
      const el = document.querySelector(selector);
      if (el) {
        log('Found input element with selector:', selector);
        return el;
      }
    }
    
    const allEditable = document.querySelectorAll('[contenteditable="true"]');
    for (const el of allEditable) {
      if (el.closest('.ds-markdown') || el.closest('.ds-message')) {
        continue;
      }
      log('Found contenteditable element');
      return el;
    }
    
    const allTextarea = document.querySelectorAll('textarea');
    for (const el of allTextarea) {
      if (!el.disabled && !el.readOnly) {
        log('Found textarea element');
        return el;
      }
    }
    
    return null;
  }

  // ==================== 注入内容到输入框 ====================
  function injectToElement(element, content) {
    const tagName = element.tagName.toLowerCase();
    const isContentEditable = element.getAttribute('contenteditable') === 'true';
    
    log('Injecting to element:', tagName, 'contentEditable:', isContentEditable);

    try {
      if (tagName === 'textarea' || tagName === 'input') {
        element.focus();
        element.value = content;
        
        element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        element.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
        element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
        element.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
        
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
          window.HTMLTextAreaElement.prototype, 'value'
        )?.set || Object.getOwnPropertyDescriptor(
          window.HTMLInputElement.prototype, 'value'
        )?.set;
        
        if (nativeInputValueSetter) {
          nativeInputValueSetter.call(element, content);
          element.dispatchEvent(new Event('input', { bubbles: true }));
        }
        
        return true;
        
      } else if (isContentEditable) {
        element.focus();
        element.innerHTML = '';
        
        const lines = content.split('\n');
        lines.forEach((line, index) => {
          if (index > 0) {
            element.appendChild(document.createElement('br'));
          }
          element.appendChild(document.createTextNode(line));
        });
        
        element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        element.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
        
        const range = document.createRange();
        const sel = window.getSelection();
        range.selectNodeContents(element);
        range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);
        
        return true;
      }
      
      return false;
    } catch (err) {
      error('Error injecting content:', err);
      return false;
    }
  }

  // ==================== 提示词注入按钮 ====================
  function createPromptButton() {
    const container = document.createElement('div');
    container.className = 'prompt-inject-container';
    
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'prompt-inject-btn idle';
    btn.innerHTML = `
      <span class="btn-icon">${CONFIG.ICONS.INJECT}</span>
      <span class="btn-text">${CONFIG.TEXT.INJECT_BTN}</span>
    `;
    
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      await handlePromptInject(btn);
    });
    
    container.appendChild(btn);
    return container;
  }

  function updateButtonState(btn, state, icon, text) {
    btn.className = `prompt-inject-btn ${state}`;
    btn.querySelector('.btn-icon').textContent = icon;
    btn.querySelector('.btn-text').textContent = text;
  }

  async function handlePromptInject(btn) {
    log('Inject button clicked');
    
    updateButtonState(btn, 'loading', CONFIG.ICONS.LOADING, CONFIG.TEXT.INJECT_LOADING);
    
    if (!promptContent) {
      const loaded = await loadPrompt();
      if (!loaded) {
        updateButtonState(btn, 'error', CONFIG.ICONS.ERROR, CONFIG.TEXT.INJECT_ERROR);
        setTimeout(() => {
          updateButtonState(btn, 'idle', CONFIG.ICONS.INJECT, CONFIG.TEXT.INJECT_BTN);
        }, 2000);
        return;
      }
    }
    
    const inputEl = findInputElement();
    
    if (!inputEl) {
      warn('Could not find input element');
      updateButtonState(btn, 'error', CONFIG.ICONS.ERROR, CONFIG.TEXT.INJECT_ERROR);
      setTimeout(() => {
        updateButtonState(btn, 'idle', CONFIG.ICONS.INJECT, CONFIG.TEXT.INJECT_BTN);
      }, 2000);
      return;
    }
    
    const success = injectToElement(inputEl, promptContent);
    
    if (success) {
      log('Prompt injected successfully');
      updateButtonState(btn, 'success', CONFIG.ICONS.SUCCESS, CONFIG.TEXT.INJECT_SUCCESS);
    } else {
      warn('Failed to inject prompt');
      updateButtonState(btn, 'error', CONFIG.ICONS.ERROR, CONFIG.TEXT.INJECT_ERROR);
    }
    
    setTimeout(() => {
      updateButtonState(btn, 'idle', CONFIG.ICONS.INJECT, CONFIG.TEXT.INJECT_BTN);
    }, 1500);
  }

  function injectPromptButton() {
    if (promptBtnInjected) return;
    
    const inputContainer = document.querySelector(CONFIG.SELECTORS.INPUT_CONTAINER);
    if (!inputContainer) return;
    
    if (inputContainer.querySelector('.prompt-inject-container')) {
      promptBtnInjected = true;
      return;
    }
    
    const btnContainer = createPromptButton();
    inputContainer.insertBefore(btnContainer, inputContainer.firstChild);
    promptBtnInjected = true;
    
    log('Prompt button injected');
  }

  // ==================== 工具函数 ====================
  
  function isThinkingBlock(codeBlock) {
    const label = codeBlock.querySelector(CONFIG.SELECTORS.LANGUAGE_LABEL);
    if (!label) return false;
    return label.textContent.trim().toLowerCase() === 'thinking';
  }

  function isBlockCompleted(codeBlock) {
    const messageContainer = codeBlock.closest(CONFIG.SELECTORS.MESSAGE_CONTAINER);
    if (!messageContainer) return false;

    const children = Array.from(messageContainer.children);
    const codeBlockIndex = children.indexOf(codeBlock);
    
    if (codeBlockIndex === -1) return false;

    for (let i = codeBlockIndex + 1; i < children.length; i++) {
      const el = children[i];
      
      if (el.classList.contains('cot-container')) continue;
      if (el.tagName === 'SVG') continue;
      
      if (el.textContent.trim().length > 0) {
        return true;
      }
      
      if (el.tagName === 'P' || el.classList.contains('ds-markdown-paragraph')) {
        return true;
      }
    }

    return false;
  }

  function debounce(func, wait) {
    let timeout;
    return function (...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => func(...args), wait);
    };
  }

  // ==================== 主处理逻辑 ====================
  
  function processCodeBlocks() {
    const codeBlocks = document.querySelectorAll(CONFIG.SELECTORS.CODE_BLOCK);
    
    codeBlocks.forEach(codeBlock => {
      if (!isThinkingBlock(codeBlock)) return;
      
      let renderer = cotRegistry.get(codeBlock);
      
      if (!renderer) {
        renderer = new COTRenderer(codeBlock);
        cotRegistry.set(codeBlock, renderer);
      } else {
        renderer.updateContent();
      }
      
      if (!renderer.isCompleted && isBlockCompleted(codeBlock)) {
        renderer.complete();
      }
    });
  }

  function processAll() {
    injectCRTFilter();
    hideOriginalButtons();
    processCodeBlocks();
    injectPromptButton();
  }

  function setupObserver() {
    const debouncedProcess = debounce(processAll, 100);
    
    const observer = new MutationObserver(() => {
      debouncedProcess();
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });

    return observer;
  }

  // ==================== 初始化 ====================
  
  async function init() {
    log('Initializing Retro Futurism Edition...');
    
    await loadPrompt();
    processAll();
    setupObserver();
    setInterval(processAll, CONFIG.CHECK_INTERVAL);
    
    log('Ready!');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 500);
  }

})();